---
home: true
actionText: 快速开始 →
actionLink: /home/
heroImage: /javascript-illustration.png
title: Study-JavaScript
features:
- title: 笔记整理
  details: 总结个人学习阶段的常用笔记,以及一些重点内容.
- title: 面试题整理
  details: 总结最近学习时候的常见面试题,还有一些踩过的坑
- title: 全面性
  details: 包含个人的vue,react,webpack,jquery,bootstarp,算法,hexo,git,es6等主流语言
- title: 混合性
  details: 整理本人开发时候踩过的Hybrid app的一些坑,包括ReactNative和Flutter
- title: 严谨性
  details: 其中的内容都是经过筛选和过滤,保证内容的可靠和严谨
- title: 有趣性
  details: 关于最新学习的一些有趣的效果或者是看到有趣的事情
footer: Copy @ 2019 - 2020 SunHang 版权所有
---

<img src="cute-javascript-git.gif">