# Vue的生命周期

1. beforeCreate

2. created

3. beforeMount

4. mounted

5. beforeUpdate

6. updated

7. activated

8. deactivated

9. beforeDestory

10. destoryed
