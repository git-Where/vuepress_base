# Vuex有哪几种属性

* state 状态中心

* mutation 修改状态的函数中心

* action 是mutation的加强,可以处理异步函数

* get 用来读取state中的数据,并在读取之前可以做一些操作

* module 对于vuex的模块化管理
