# 前端基础知识汇总

## 思维导图

<a data-fancybox title="xx" target="_blank" href="https://cdn.jsdelivr.net/gh/2662419405/imgPlus/interview.a96f12f4.jpg">![xx](https://cdn.jsdelivr.net/gh/2662419405/imgPlus/interview.a96f12f4.jpg)</a>

如果需要可以下载下去再看
