# 北京

## 导航栏鼠标滑过效果和点击事件选中效果一致时, 怎么解决两个事件的冲突

## 让一个层 ( 盒子 ) 在页面中垂直居中于浏览器中

## 简述CSS3常用属性及作用

## 对于以下json字符串 ,怎么获取到CourseName = 3F 的这条记录

``` js
{ "CourseName" : "B1" , "CourseID" : "6"}
{ "CourseName" : "4F" , "CourseID" : "5"}
{ "CourseName" : "3F" , "CourseID" : "4"}
```

## 简述对伪类的理解及用法 , 列举几个常用的伪类 ,

## 请描述 margin-left:300px; 和 margin-right:-300px;

## 下面代码中123的颜色是什么?

``` js
/
<style>
    .classA{color : blue ;}
    .classB{color : red ;}
</style>
<body>
    <div class ="classB classA"> 123 </div>
</body>
/
```

## 页面上的透明层效果怎么实现? 需要兼容ie 各个版本 